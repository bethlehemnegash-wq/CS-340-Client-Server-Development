# CRUD Python Module for the AAC Animal Shelter Database

from pymongo import MongoClient


class AnimalShelter:
    """CRUD operations for the Animal collection in MongoDB."""

    def __init__(self, username, password):
        # Connection variables for the AAC database
        USER = username
        PASS = password
        HOST = "localhost"
        PORT = 27017
        DB = "aac"
        COL = "animals"

        # Connect to MongoDB using the username and password
        self.client = MongoClient(
            "mongodb://%s:%s@%s:%d/?authSource=%s"
            % (USER, PASS, HOST, PORT, DB)
        )

        # Access the AAC database and animals collection
        self.database = self.client[DB]
        self.collection = self.database[COL]

    # Create a new document in the animals collection
    def create(self, data):
        if data is not None:
            try:
                self.collection.insert_one(data)
                return True
            except Exception:
                return False
        return False

    # Read documents from the animals collection
    def read(self, query):
        if query is not None:
            try:
                results = self.collection.find(query)
                return list(results)
            except Exception:
                return []
        return []

    # Update documents in the animals collection
    def update(self, query, new_data):
        if query is not None and new_data is not None:
            try:
                result = self.collection.update_many(
                    query,
                    {"$set": new_data}
                )
                return result.modified_count
            except Exception:
                return 0
        return 0

    # Delete documents from the animals collection
    def delete(self, query):
        if query is not None:
            try:
                result = self.collection.delete_many(query)
                return result.deleted_count
            except Exception:
                return 0
        return 0